package cz.cvut.fel.pjv;

public class BruteForceAttacker extends Thief {
    
   
    @Override
    public void breakPassword(int sizeOfPassword) {
        char[] characters = getCharacters();
        char [] possiblePassword = new char[sizeOfPassword];
        for(int i = 0; i < sizeOfPassword; i++){
            possiblePassword[i] = characters[0];
        }
        int help = 0;
        helpFunction(possiblePassword, sizeOfPassword-1, characters, help);
    }
    private boolean helpFunction(char[] possiblePassword,int sizeOfPassword, char[] characters, int help){
        
        if(tryOpen(possiblePassword)){
            return true;
        } 
        if(help == sizeOfPassword){
            return false;
        } else {
            
            for(int i = 0; i < characters.length; i++){
                possiblePassword[help] = characters[i];
                if(helpFunction(possiblePassword, sizeOfPassword, characters, help+1)){
                    return true;
                }
                
            }
        }
        return false;
    }
}

