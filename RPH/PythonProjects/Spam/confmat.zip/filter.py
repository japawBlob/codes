import os
import corpus


class MyFilter:

    def train(self, path):
        pass

    def test(self, path):
        data = corpus.Corpus(path)

        with open(os.path.join(path, "!prediction.txt"), 'w+', encoding='utf-8') as f:
            for name, body in data.emails():
                f.write("%s OK" % name)