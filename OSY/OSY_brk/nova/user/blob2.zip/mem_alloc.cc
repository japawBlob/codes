extern "C" void *my_malloc(unsigned int size);
extern "C" int my_free(void *address);
/*
#include "ec.h"
#include "kalloc.h"
#include "ptab.h"
#include "types.h"
#include "string.h"
#include "bits.h"
#include "memory.h"
*/
unsigned syscall2(unsigned w0, unsigned w1){
    asm volatile (
        "   mov %%esp, %%ecx    ;"
        "   mov $1f, %%edx      ;"
        "   sysenter            ;"
        "1:                     ;"
        : "+a" (w0) : "S" (w1) : "ecx", "edx", "memory");
    return w0;
}

void *brk(void *address){
    return (void*)syscall2(3, (unsigned)address);
}

typedef char ALIGN[16];

union header {
	struct {
		unsigned int size;
		unsigned is_free;
		union header *next;
	} s;
	ALIGN stub;
};
typedef union header header_t;

header_t *head, *tail;


header_t *get_free_block(unsigned int size)
{
	header_t *curr = head;
	while(curr) {
		if (curr->s.is_free && curr->s.size >= size)
			return curr;
		curr = curr->s.next;
	}
	return NULL;
}

void *malloc(unsigned int size)
{
	unsigned int total_size;
	void *block;
	header_t *header;
	unsigned int originalBrk = brk(0);
	if (!size)
		return NULL;
//	pthread_mutex_lock(&global_malloc_lock);
	header = get_free_block(size);
	if (header) {
		header->s.is_free = 0;
//		pthread_mutex_unlock(&global_malloc_lock);
		return (void*)(header + 1);
	}
	total_size = sizeof(header_t) + size;
	block = brk(originalBrk+total_size);
	if (block == (void*) -1) {
//		pthread_mutex_unlock(&global_malloc_lock);
		return NULL;
	}
	header = block;
	header->s.size = size;
	header->s.is_free = 0;
	header->s.next = NULL;
	if (!head)
		head = header;
	if (tail)
		tail->s.next = header;
	tail = header;
//	pthread_mutex_unlock(&global_malloc_lock);
	return (void*)(header + 1);
}


void free(void *block)
{
	header_t *header, *tmp;
	void *programbreak;

	if (!block)
		return;
//	pthread_mutex_lock(&global_malloc_lock);
	header = (header_t*)block - 1;

	programbreak = brk(0);
	if ((char*)block + header->s.size == programbreak) {
		if (head == tail) {
			head = tail = NULL;
		} else {
			tmp = head;
			while (tmp) {
				if(tmp->s.next == tail) {
					tmp->s.next = NULL;
					tail = tmp;
				}
				tmp = tmp->s.next;
			}
		}
		brk(programbreak - sizeof(header_t) - header->s.size);
//		pthread_mutex_unlock(&global_malloc_lock);
		return;
	}
	header->s.is_free = 1;
//	pthread_mutex_unlock(&global_malloc_lock);
}