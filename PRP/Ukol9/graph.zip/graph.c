#include <stdio.h>
#include <stdlib.h>
#include "graph.h"

#define ARR graph->arr
#define COUNTER graph->counter
#define CAPACITY graph->capacity

int to_int(char c){
	return c - 48;
}

void read (int what, char c, FILE *f){
	what = to_int(c);
	c = fgetc(f);
	while(c != ' ' && c != '\n'){
		what *= 10;
		what += to_int(c);
		c = fgetc(f);
	}
}


graph_t* allocate_graph(){
	graph_t *graph;
	graph = (graph_t*)malloc(sizeof(graph_t));
	CAPACITY = 20;
	COUNTER = 0;
	ARR = (int**)malloc(CAPACITY*sizeof(int*));
	
	for(int i = 0; i<CAPACITY; i++){
		ARR[i] = (int*)malloc(3*sizeof(int));
	}
	return graph;
}



void free_graph(graph_t **graph){
	for(int i = 0; i<(*graph)->capacity; i++){
		free((*graph)->arr[i]);
	}
	free((*graph)->arr);
	free(*graph);
}



void load_txt(const char *fname, graph_t *graph){
	FILE *f = fopen(fname, "r");
	int first_node = 0;
	int second_node = 0;
	int path = 0;
	char c;
	
	while((c = fgetc(f)) != EOF){
		read(first_node, c, f);
		c = fgetc(f);
		read(second_node, c, f);
		c = fgetc(f);
		read(path, c, f);
		ARR[COUNTER][0] = first_node;
		ARR[COUNTER][1] = second_node;
		ARR[COUNTER][2] = path;
		
		COUNTER++;
		
		if(COUNTER == CAPACITY){
			ARR = (int**)realloc(ARR, 2*CAPACITY*sizeof(int*));
			for(int i = CAPACITY; i<2*CAPACITY; i++){
				ARR[CAPACITY] = (int*)malloc(3*sizeof(int));
			}
			CAPACITY *= 2; 
		}
	}
	fclose(f);
}




void load_bin(const char *fname, graph_t *graph){
	FILE* f = fopen(fname, "rb");
	int first_node;
	int second_node;
	int path;
//	int blob;
	
	while(fread(&first_node, sizeof(int), 1, f) != 0){
		if(fread(&second_node, sizeof(int), 1, f) == 0){
			break;
		}
		if(fread(&path, sizeof(int), 1, f) == 0){
			break;
		}
		ARR[COUNTER][0] = first_node;
		ARR[COUNTER][1] = second_node;
		ARR[COUNTER][2] = path;
		
		COUNTER++;
		
		if(COUNTER == CAPACITY){
			ARR = (int**)realloc(ARR, 2*CAPACITY*sizeof(int*));
			for(int i = CAPACITY; i<2*CAPACITY; i++){
				ARR[CAPACITY] = (int*)malloc(3*sizeof(int));
			}
			CAPACITY *= 2; 
		}
	}
	
}



void save_txt(const graph_t * const graph, const char *fname){
	FILE* f = fopen(fname, "w");
	for(int i = 0; i < COUNTER; i++){
		for(int j = 0; j < 3; j++)
		fprintf(f,"%i",ARR[i][j]);
		if(i != 2){
			fputc(' ', f);
		} else {
			fputc('\n', f);
		}
	}
	fclose(f);
}



void save_bin(const graph_t * const graph, const char *fname){
	FILE* f = fopen(fname, "wb");
	for(int i = 0; i < COUNTER; i++){
            fwrite(&ARR[i][0], sizeof(int), 1, f);
            fwrite(&ARR[i][1], sizeof(int), 1, f);
            fwrite(&ARR[i][2], sizeof(int), 1, f);
	}
	fclose(f);
}



