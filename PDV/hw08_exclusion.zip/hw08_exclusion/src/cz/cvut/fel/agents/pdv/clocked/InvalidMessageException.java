package cz.cvut.fel.agents.pdv.clocked;

public class InvalidMessageException extends RuntimeException {
    public InvalidMessageException(String s) {
        super(s);
    }
}
