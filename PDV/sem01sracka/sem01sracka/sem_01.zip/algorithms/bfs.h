#ifndef PDV_SEARCH_BFS_H
#define PDV_SEARCH_BFS_H

#include "../state.h"

std::shared_ptr<const state> bfs(std::shared_ptr<const state> root);

#endif //PDV_SEARCH_BFS_H
