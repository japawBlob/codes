#ifndef PDV_SEARCH_IDDFS_H
#define PDV_SEARCH_IDDFS_H

#include "../state.h"

std::shared_ptr<const state> iddfs(std::shared_ptr<const state> root);

#endif //PDV_SEARCH_IDDFS_H
