package cz.cvut.fel.agents.dsand;

public class TerminateAllMessage extends Message {
}
