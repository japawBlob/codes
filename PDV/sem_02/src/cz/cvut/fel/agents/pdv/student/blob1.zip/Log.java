package cz.cvut.fel.agents.pdv.student;

public class Log {


    public Log(){
    }
}
