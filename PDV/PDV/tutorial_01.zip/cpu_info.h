#ifndef PDVCRYPT_CPU_INFO_H
#define PDVCRYPT_CPU_INFO_H

// Tato funkce vrati pocet fyzickych jader procesoru
int get_num_cores();

#endif
