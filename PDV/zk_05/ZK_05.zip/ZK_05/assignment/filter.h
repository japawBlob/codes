#ifndef ZK_05_FILTER_H
#define ZK_05_FILTER_H

#include "data_table.h"

void filtering(data_table& table, unsigned int iterations);

#endif //ZK_05_FILTER_H
