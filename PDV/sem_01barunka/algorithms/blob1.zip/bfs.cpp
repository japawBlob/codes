#include "bfs.h"
#include "../state.h"
#include <iostream>
#include <queue>
#include <set>

// Naimplementujte efektivni algoritmus pro nalezeni nejkratsi cesty v grafu.
// V teto metode nemusite prilis optimalizovat pametove naroky, a vhodnym algo-
// ritmem tak muze byt napriklad pouziti prohledavani do sirky (breadth-first
// search.
//
// Metoda ma za ukol vratit ukazatel na cilovy stav, ktery je dosazitelny pomoci
// nejkratsi cesty. Pokud je nejkratsich cest vice, vratte ukazatel na stav s nej-
// nizsim identifikatorem (viz metoda 'state::get_identifier()' v 'state.h').
std::shared_ptr<const state> bfs(std::shared_ptr<const state> root) {

    std::queue <std::vector<std::shared_ptr<const state>>> q;
    std::vector <std::shared_ptr<const state>> exp;
    std::shared_ptr<const state> goal;
    std::vector<std::shared_ptr<const state>> wtf = root->next_states();
    std::set <unsigned long long> visited;


    q.push(wtf);
    visited.insert(root->get_identifier());
    //printf("root size %i", visited.size());
    int ooze = 0;
    while(!q.empty()){
        exp = q.front();
        q.pop();

        for (int i = 0; i <exp.size(); ++i) {
            //printf("for 1\n");
            if(exp[i] != NULL){
                if (exp[i]->is_goal()) {
                    //printf("added\n");
                    if(goal == nullptr){
                        goal = exp[i];
                    }
                    if(goal->current_cost() > exp[i]->current_cost()) {
                        goal = exp[i];
                        // printf("%s\n", exp[i]->to_string().str_c);
                    }
                    //printf("%s\n", exp[i]->to_string().c_str());
                    //goto blob;
                }
                std::vector<std::shared_ptr<const state>> tmp1;
                std::vector<std::shared_ptr<const state>> tmp2(exp.size()+1);
                tmp1 = exp[i]->next_states();
                int pos = 0;
                for(int l = 0; l < tmp1.size(); l++){
                    //printf("for2\n");
                    if(visited.count(tmp1[l]->get_identifier()) == 0){
                        //printf("if check\n");
                        tmp2[pos] = tmp1[l];
                        visited.insert(tmp1[l]->get_identifier());
                        //printf("add check\n");
                        pos++;
                    }
                }
                q.push(tmp2);
                //printf("pushed\n");
            }
        }
        //printf("%i\n", ooze++);
    }

    //blob:
        std::shared_ptr<const state> ret;
        ret = goal;
    return ret;
}