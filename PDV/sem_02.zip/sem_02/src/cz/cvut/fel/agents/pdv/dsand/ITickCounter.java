package cz.cvut.fel.agents.pdv.dsand;

public interface ITickCounter {

  long getCurrentTick();

}
