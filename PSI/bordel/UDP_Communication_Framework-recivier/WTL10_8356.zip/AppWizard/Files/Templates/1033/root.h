// [!output PROJECT_NAME].h
