To compile the HtmlHelp file into the .chm, use the free HTML Help Workshop from Microsoft.
Currently, you can download this from
	http://msdn.microsoft.com/library/default.asp?url=/library/en-us/htmlhelp/html/hwMicrosoftHTMLHelpDownloads.asp
or
	http://go.microsoft.com/fwlink/?LinkId=14188
or
	http://www.microsoft.com/downloads/details.aspx?FamilyID=00535334-c8a6-452f-9aa0-d597d16580cc&DisplayLang=en
or
	http://download.microsoft.com/download/0/a/9/0a939ef6-e31c-430f-a3df-dfae7960d564/htmlhelp.exe