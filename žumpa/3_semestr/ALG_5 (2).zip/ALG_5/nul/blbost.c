#include <stdio.h>

int main(){
	printf("HELLO WORLD");
	return 0;	
}
